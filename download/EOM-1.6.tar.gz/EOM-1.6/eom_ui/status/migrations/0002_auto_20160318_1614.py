# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('status', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Cache',
            fields=[
                ('cache_id', models.IntegerField(serialize=False, primary_key=True)),
                ('host', models.TextField()),
                ('port', models.TextField()),
                ('version', models.IntegerField(null=True, blank=True)),
                ('nonce', models.IntegerField(null=True, blank=True)),
                ('serial', models.IntegerField(null=True, blank=True)),
                ('updated', models.IntegerField(null=True, blank=True)),
                ('refresh', models.IntegerField(null=True, blank=True)),
                ('retry', models.IntegerField(null=True, blank=True)),
                ('expire', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'cache',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Prefix',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cache_id', models.IntegerField()),
                ('asn', models.IntegerField()),
                ('prefix', models.TextField()),
                ('prefixlen', models.IntegerField()),
                ('max_prefixlen', models.IntegerField()),
                ('prefix_min', models.TextField(blank=True)),
                ('prefix_max', models.TextField(blank=True)),
            ],
            options={
                'db_table': 'prefix',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='ReportDetail',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('report_id', models.IntegerField()),
                ('invalid', models.TextField()),
                ('status', models.TextField()),
                ('pfx', models.TextField()),
                ('pfxlen', models.TextField()),
                ('pfxstr_min', models.TextField()),
                ('pfxstr_max', models.TextField()),
                ('nexthop', models.TextField()),
                ('metric', models.TextField()),
                ('locpref', models.TextField()),
                ('weight', models.TextField()),
                ('pathbutone', models.TextField()),
                ('orig_asn', models.TextField()),
                ('route_orig', models.TextField()),
                ('rconstraint', models.TextField()),
            ],
            options={
                'db_table': 'report_detail',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='ReportIndex',
            fields=[
                ('report_id', models.IntegerField(serialize=False, primary_key=True)),
                ('device', models.TextField()),
                ('timestamp', models.IntegerField()),
            ],
            options={
                'db_table': 'report_index',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Routerkey',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cache_id', models.IntegerField()),
                ('asn', models.IntegerField()),
                ('ski', models.TextField()),
                ('key', models.TextField()),
            ],
            options={
                'db_table': 'routerkey',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='RtrCache',
            fields=[
                ('rtr_id', models.IntegerField(serialize=False, primary_key=True)),
                ('device', models.TextField(unique=True)),
            ],
            options={
                'db_table': 'rtr_cache',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='RtrRib',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('rtr_id', models.IntegerField()),
                ('idx', models.IntegerField()),
                ('status', models.TextField(blank=True)),
                ('pfx', models.TextField()),
                ('pfxlen', models.IntegerField()),
                ('pfxstr_min', models.TextField()),
                ('pfxstr_max', models.TextField()),
                ('nexthop', models.TextField()),
                ('metric', models.IntegerField(null=True, blank=True)),
                ('locpref', models.IntegerField(null=True, blank=True)),
                ('weight', models.IntegerField(null=True, blank=True)),
                ('pathbutone', models.TextField(blank=True)),
                ('orig_asn', models.IntegerField()),
                ('route_orig', models.TextField(blank=True)),
            ],
            options={
                'db_table': 'rtr_rib',
                'managed': False,
            },
            bases=(models.Model,),
        ),
        migrations.DeleteModel(
            name='Route',
        ),
    ]
