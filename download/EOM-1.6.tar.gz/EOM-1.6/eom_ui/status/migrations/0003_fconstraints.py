# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('status', '0002_auto_20160318_1614'),
    ]

    operations = [
        migrations.CreateModel(
            name='Fconstraints',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('report_id', models.TextField()),
                ('asn', models.TextField()),
                ('prefix', models.TextField()),
            ],
            options={
                'db_table': 'fconstraints',
                'managed': False,
            },
            bases=(models.Model,),
        ),
    ]
